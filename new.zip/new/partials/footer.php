   <div class="footer">
   	 <div class="wrap">
   	 <div class="section group example">
				<div class="col_1_of_4 span_1_of_4 list">
				   <h3>Overview</h3>
				   <ul>
				   	<li><a href="#">About Us</a></li>			   
				   </ul>				   
 				</div>
 				<div class="col_1_of_4 span_1_of_4 list">
				   <h3>Support</h3>
				   <ul>
				   	<li><a href="#">Support Portal</a></li>		   
				   </ul>				   
 				</div>
				<div class="col_1_of_4 span_1_of_4 list">
				   <h3>Partners</h3>
				   <ul>
				   	<li><a href="#">Paypal</a></li>			   
				   </ul>				   
 				</div>
				<div class="col_1_of_4 span_1_of_4 list">
				   <h3>Contact Us</h3>
				   <ul>
				   	<li><a href="#">+254-721-307272</a></li>
				   	<li><a href="#">Ambassador Court, Room B5 <br>
					Milimani Road<br>
					P.O Box 53911-00200 <br>
					Nairobi, Kenya</a></li>				   
				   </ul>	
				        <div class="social-icons">
							<h3>Stay in touch</h3>
					   		  <ul>
							      <li><a href="https://www.facebook.com/AfricaGenderCenter/" target="_blank"> <img src="images/facebook.png" alt="" /> Facebook</a></li>
							      <li class="twitter"><a href="https://twitter.com/agrigender" target="_blank"> <img src="images/twitter.png" alt="" /> Twitter</a></li>
							      <!-- <li class="googleplus"><a href="#" target="_blank"><img src="images/googleplus.png" alt="" />  Google+</a></li>
							      <li class="pinterest"><a href="#" target="_blank"><img src="images/pinterest.png" alt="" /> Pinterest</a></li> -->
							     <!--  <li class="likedin"><a href="#" target="_blank"><img src="images/likedin.png" alt="" /> Likedin</a></li> -->
							      <div class="clear"></div>
						     </ul>
   	 					</div>			   
 				</div>
				<div class="clear"></div>
		    </div>
		  </div> 
       </div> 
		     <div class="copy_right">
		     	<div class="wrap" style="color: #fff !important;">
				    <p>&copy; 2016 Africa Gender Center | Design by  <a href="ccoretechnologies.com" target="_blank"> Kevin/CloudCore Technogies</a></p>
		     	</div>
		   	</div>		 		 
	</body>
</html>

