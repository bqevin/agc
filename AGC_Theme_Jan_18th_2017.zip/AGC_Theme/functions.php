<?php
// This theme uses post thumbnails
add_theme_support( 'post-thumbnails' );
?>