<!--Header Partial-->	
<?php include('partials/header.php');?>
<!--Body Partial-->	      	
     <div class="main">
	 	<div class="content">	
	 		 <div class="content_top">  
	 		     <div class="wrap">                                  		
            	   <div class="banner_desc">
            		<h1>Africa <span>Gender</span> Center </h1>  
            		<h3>Consultancy company on Gender, Social <br /> Research and Impact Assessment</h3>
            		<a class="play_icon fancybox-media" href="#"><img src="images/play-icon.png" alt="" /></a>
            		<h3>Get our reasearches <span>inboxed</span>!</h3>
            		<p>No spamming. We promise</p>
            		 <div class="sign_up">				  	
					 <form>
					  		<input style="padding: 3px 2px 1px;" type="text" value="E-mail address " onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'E-mail address';}"> 
					 		<input type="submit" value="Subscribe" style="padding: 11px 20px;">

					  </form>
				    </div>
                </div>  
                     <div class="ipad">
            		     <img src="images/ipad.png" alt="" />
            	     </div>
             <div class="clear"></div>
        </div>
   	  	</div>
   	  	       <div class="features" >
	                 <div class="wrap">                             	
                 		  <h2>get in <span>touch</span></h2>
                 		    <h4>Send a message below</h4>
                 		    
                 		    <div class="row">
						    <form class="col s12">
						      <div class="row">
						        <div class="input-field col s5">
						          <i class="material-icons prefix">account_circle</i>
						          <input id="icon_prefix" type="text" class="validate">
						          <label for="icon_prefix">Full Name</label>
						        </div>
						        <div class="input-field col s5">
						          <i class="material-icons prefix">email</i>
						          <input id="icon_telephone" type="tel" class="validate">
						          <label for="icon_telephone">Email</label>
						        </div>
						       
						        <div class="row">
						        <div class="input-field col s10">
						          <i class="material-icons prefix">mode_edit</i>
						          <textarea id="icon_prefix2" class="materialize-textarea"></textarea>
						          <label for="icon_prefix2">Message</label>
						        </div>
						        </div>
						      </div>
						      <button style="z-index: 0" class="btn waves-effect waves-light btn-large" type="submit" name="action">Send Message
							    <i class="material-icons right">send</i>
							  </button>
						    </form>
						  </div>
						</div>
           			</div>
            

     		</div>
  		 </div>	
<!--Footer Partial-->	
<?php include('partials/footer.php');?>